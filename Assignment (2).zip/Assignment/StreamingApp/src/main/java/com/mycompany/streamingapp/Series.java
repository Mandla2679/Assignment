/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.streamingapp;

/**
 *
 * @author RC_Student_lab
 */
import java.util.ArrayList;
import java.util.Scanner;

public class Series {
    private ArrayList<SeriesModel> seriesList = new ArrayList<>();
    private Scanner in = new Scanner(System.in);

    //Capture a new series
    public void CaptureSeries() {
        System.out.println("CAPTURE A NEW SERIES");
        System.out.println("*************************");

        System.out.print("Enter the series id: ");
        String id = in.nextLine();

        System.out.print("Enter the series name: ");
        String name = in.nextLine();

        String age;
        while (true) {
            System.out.print("Enter the series age restriction: ");
            age = in.nextLine();
            if (age.matches("\\d+")) {
                int ageNum = Integer.parseInt(age);
                if (ageNum >= 2 && ageNum <= 18) {
                    break;
                }
            }
            System.out.println("You have entered an incorrect series age!!!");
            System.out.print("Please re-enter the series age >> ");
        }
  //Number of episodes insertion
        System.out.print("Enter the number of episodes for " + name + ": ");
        String episodes = in.nextLine();

        seriesList.add(new SeriesModel(id, name, age, episodes));
        System.out.println("Series processed successfully!!!");
    }

    // Search for a series
    public void SearchSeries() {
        System.out.print("Enter the series id to search: ");
        String id = in.nextLine();

        for (SeriesModel s : seriesList) {
            if (s.SeriesId.equals(id)) {
                System.out.println("SERIES ID: " + s.SeriesId);
                System.out.println("SERIES NAME: " + s.SeriesName);
                System.out.println("SERIES AGE RESTRICTION: " + s.SeriesAge);
                System.out.println("SERIES NUMBER OF EPISODES: " + s.SeriesNumberOfEpisodes);
                return;
            }
        }
        System.out.println("Series with Series Id: " + id + " was not found!");
    }

    //  Update series details
    public void UpdateSeries() {
        System.out.print("Enter the series id to update: ");
        String id = in.nextLine();

        for (SeriesModel s : seriesList) {
            if (s.SeriesId.equals(id)) {
                System.out.print("Enter new series name: ");
                s.SeriesName = in.nextLine();

                String age;
                while (true) {
                    System.out.print("Enter new series age restriction: ");
                    age = in.nextLine();
                    if (age.matches("\\d+")) {
                        int ageNum = Integer.parseInt(age);
                        if (ageNum >= 2 && ageNum <= 18) {
                            s.SeriesAge = age;
                            break;
                        }
                    }
                    System.out.println("You have entered an incorrect series age!!!");
                    System.out.print("Please re-enter the series age >> ");
                }

                System.out.print("Enter new number of episodes: ");
                s.SeriesNumberOfEpisodes = in.nextLine();

                System.out.println("Series updated successfully!");
                return;
            }
        }
        System.out.println("Series with Series Id: " + id + " was not found!");
    }

    //  Delete a series
    public void DeleteSeries() {
        System.out.print("Enter the series id to delete: ");
        String id = in.nextLine();

        for (SeriesModel s : seriesList) {
            if (s.SeriesId.equals(id)) {
                System.out.print("Are you sure you want to delete series " + id + " from the system? Yes (y) to delete: ");
                String confirm = in.nextLine();
                if (confirm.equalsIgnoreCase("y")) {
                    seriesList.remove(s);
                    System.out.println("Series with Series Id: " + id + " WAS deleted!");
                } else {
                    System.out.println("Delete operation cancelled.");
                }
                return;
            }
        }
        System.out.println("Series with Series Id: " + id + " was not found!");
    }

    //Print series report
    public void SeriesReport() {
        if (seriesList.isEmpty()) {
            System.out.println("No series captured yet.");
            return;
        }
        int count = 1;
        for (SeriesModel s : seriesList) {
            System.out.println("Series " + count);
            System.out.println("SERIES ID: " + s.SeriesId);
            System.out.println("SERIES NAME: " + s.SeriesName);
            System.out.println("SERIES AGE RESTRICTION: " + s.SeriesAge);
            System.out.println("NUMBER OF EPISODES: " + s.SeriesNumberOfEpisodes);
            count++;
        }
    }

    // Exit
    public void ExitSeriesApplication() {
        System.out.println("Exiting application... Goodbye!");
        System.exit(0);
    }
}

