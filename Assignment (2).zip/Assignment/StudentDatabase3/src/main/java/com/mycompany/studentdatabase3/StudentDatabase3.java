/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.studentdatabase3;

import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class StudentDatabase3 {

    public static void main(String[] args) {
        //Ask how many new students we wanna add
        System.out.println("Enter number of students you want to enroll");
        Scanner in = new Scanner(System.in);
        int numOfStudents = in.nextInt();
        Student3[] students = new Student3[numOfStudents];
        
        for(int n = 0; n < numOfStudents; n++){
          students[n] = new Student3();
          students[n].enroll();
          students[n].payTuition(n);
        }
  
      
        for (int n = 0; n < numOfStudents; n++){
            System.out.println(students[n].toString());
        }
        
        
    }
}
